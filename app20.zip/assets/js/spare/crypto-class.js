class Crypto {
    constructor(name, symbol, id) {
        this.name = name;
        this.symbol = symbol;
        this.id = id;
        this.price = null;
        this.circulatingSupply = null;
        this.marketCap = null;
        this.priceChange = null;
        this.volume = null;
    }

    async fetchPriceData() {
        const response = await fetch(`https://api.binance.com/api/v3/ticker/24hr?symbol=${this.symbol}USDT`);
        const data = await response.json();
        this.price = parseFloat(data.lastPrice);
        this.priceChange = parseFloat(data.priceChangePercent);
        this.volume = parseFloat(data.volume);
    }

    async fetchCirculatingSupply() {
        const response = await fetch(`https://min-api.cryptocompare.com/data/coinsnapshotfullbyid?id=${this.id}`);
        const data = await response.json();
        this.circulatingSupply = data.Data.CirculatingSupply;
    }

    calculateMarketCap() {
        if (this.price !== null && this.circulatingSupply !== null) {
            this.marketCap = this.price * this.circulatingSupply;
            return this.marketCap;
        }
        return null;
    }

    static calculateRank(cryptos) {
        return cryptos
            .map(crypto => ({
                name: crypto.name,
                marketCap: crypto.calculateMarketCap()
            }))
            .sort((a, b) => b.marketCap - a.marketCap)
            .map((crypto, index) => ({
                rank: index + 1,
                name: crypto.name,
                marketCap: crypto.marketCap
            }));
    }

    async fetchData() {
        await Promise.all([this.fetchPriceData(), this.fetchCirculatingSupply()]);
    }
}

// Dictionary to hold crypto instances
const cryptos = {
    bitcoin: new Crypto('Bitcoin', 'BTC', '1'),
    ethereum: new Crypto('Ethereum', 'ETH', '1027'),
    dogecoin: new Crypto('Dogecoin', 'DOGE', '74')
};

// Usage example
(async () => {
    await Promise.all([
        cryptos.bitcoin.fetchData(),
        cryptos.ethereum.fetchData(),
        cryptos.dogecoin.fetchData()
    ]);

    Object.values(cryptos).forEach(crypto => {
        console.log(`${crypto.name}: Price: $${crypto.price}, Circulating Supply: ${crypto.circulatingSupply}, Market Cap: $${crypto.calculateMarketCap()}`);
    });

    const rankedCryptos = Crypto.calculateRank(Object.values(cryptos));
    console.log('Ranked Cryptos by Market Cap:', rankedCryptos);
})();