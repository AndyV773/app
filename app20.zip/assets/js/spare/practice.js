// script.js

// Function to load more content when scrolling
function loadMoreContent() {
    const content = document.getElementById('content');

    // Simulating new items being added
    const newItem = document.createElement('div');
    newItem.classList.add('item');
    newItem.textContent = `Item ${content.children.length + 1}`;
    
    content.appendChild(newItem); // Append new item to the right
}

// Detect when the user scrolls to the end of the container
function checkScroll() {
    const container = document.getElementById('container');
    const content = document.getElementById('content');

    // When user scrolls to the right end, load more content
    if (container.scrollLeft + container.clientWidth >= content.scrollWidth - 50) {
        loadMoreContent();
    }
}

// Initial load of content (optional)
loadMoreContent(); // Start by adding one item at the end

// Event listener for scroll detection
document.getElementById('container').addEventListener('scroll', checkScroll);