const cryptoIds = {
    Bitcoin: '1',
    Ethereum: '1027',
    Tether: '825',
    BinanceCoin: '2710',
    Cardano: '2010',
    XRP: '52',
    Solana: '5426',
    Polkadot: '3296',
    Dogecoin: '74',
    USD_Coin: '3408'
};

const fetchCirculatingSupply = async () => {
    const promises = Object.entries(cryptoIds).map(async ([name, id]) => {
        const response = await fetch(`https: //min-api.cryptocompare.com/data/coinsnapshotfullbyid?id=${id}`);
        const data = await response.json();

        if (data && data.Data) {
            return {
                name,
                circulatingSupply: data.Data.CirculatingSupply
            };
        } else {
            return {
                name,
                circulatingSupply: null
            };
        }
    });

    const results = await Promise.all(promises);
    console.log(results);
};

fetchCirculatingSupply();