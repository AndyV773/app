import {
    updateCreditsDisplay,
    addCredit
} from '../credits.js'; // Import functions from credits.js

// Get the current page's filename
const currentPage = "check-in.html";
// Check and save the corresponding key to local storage
localStorage.setItem('firstpage', currentPage); // Save "firstpage" key
// Log the stored values for verification
console.log('First Page:', localStorage.getItem('firstpage'));

let currentDate = new Date();
let checkButton = document.getElementById('daily-check-in-button');

function renderCalendar() {
    const monthYearElement = document.getElementById('month-year');
    const daysElement = document.getElementById('days');

    // Get the current month and year
    const month = currentDate.getMonth();
    const year = currentDate.getFullYear();

    // Get today's day
    const today = currentDate.getDate();

    // Set the month and year in the header
    monthYearElement.textContent = `${currentDate.toLocaleString('default', { month: 'long' })} ${year}`;

    // Clear previous days
    daysElement.innerHTML = '';

    // Calculate the total number of days in the month
    const totalDays = new Date(year, month + 1, 0).getDate();

    // Add squares for each day of the month
    for (let day = 1; day <= totalDays; day++) {
        const daySquare = document.createElement('div');
        // daySquare.className = 'day';
        daySquare.classList.add('day'); // Adds 'day' to the existing classes


        // Highlight today's day
        if (day === today) {
            daySquare.classList.add('today'); // Add a class to style today
        }

        daySquare.innerHTML = `${day}<i class="fa-solid fa-tag"></i><span>+ 1</span>`;
        daysElement.appendChild(daySquare);
    }
}

// Initial render
renderCalendar();

// function checkIn() {

//     const day = currentDate.getDate();
//     let today = document.getElementsByClassName('today')[0];
//     today.classList.add = 'checked';
//     today.innerHTML = `${day}<i class="fa-solid fa-circle-check"></i>`;

// }

function checkIn() {
    const today = document.getElementsByClassName('today')[0];
    const checked = 'checked';
    const day = currentDate.getDate();

    // Add the class if it doesn't already exist
    if (!today.classList.contains(checked)) {
        today.classList.add(checked);
        today.innerHTML = `${day}<i class="fa-solid fa-circle-check"></i>`;
        localStorage.setItem('checkClass', checked); // Store the class in localStorage
    }
}

// Wait for the DOM to load before adding event listeners
window.addEventListener("DOMContentLoaded", () => {
    // Update the display on load
    updateCreditsDisplay();

    // Add event listener to the button
    if (checkButton) {
        checkButton.addEventListener("click", checkIn);
        checkButton.addEventListener("click", addCredit); // Add event listener for adding credits
    }
});

window.onload = function () {
    const element = document.getElementsByClassName('checked');
    const savedClass = localStorage.getItem('checkClass');

    if (savedClass) {
        element.classList.add(savedClass);
    }
};