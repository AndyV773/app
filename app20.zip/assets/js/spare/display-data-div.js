let cryptoData = {}; // Declare globally
let sortDirection = 'desc'; // Default sort direction
let sortByVolume = false; // Track sorting by volume


export function formatVolumePercentage(priceChangePercent) {
    return `${priceChangePercent.toFixed(2)}%`; // Format as percentage
}

export function formatMarketCap(marketCap) {
    if (marketCap >= 1e12) {
        return (marketCap / 1e12).toFixed(2) + 'T'; // Trillions
    } else if (marketCap >= 1e9) {
        return (marketCap / 1e9).toFixed(2) + 'B'; // Billions
    } else if (marketCap >= 1e6) {
        return (marketCap / 1e6).toFixed(2) + 'M'; // Millions
    } else {
        return marketCap.toFixed(2); // Otherwise, just format as is
    }
}

export function displayData(data) {
    cryptoData = data; // Update the global cryptoData variable
    const dataWithRanking = Object.entries(cryptoData)
        .map(([symbol, data]) => ({
            symbol,
            ...data
        }));

    // Create a ranking based on market cap
    const rankingMap = dataWithRanking
        .slice()
        .sort((a, b) => b.marketCap - a.marketCap)
        .map((data, index) => ({
            symbol: data.symbol,
            rank: index + 1
        }))
        .reduce((acc, curr) => {
            acc[curr.symbol] = curr.rank;
            return acc;
        }, {});

    const sortedData = dataWithRanking.sort((a, b) => {
        if (sortByVolume) {
            return sortDirection === 'desc' ? b.volume - a.volume : a.volume - b.volume;
        }
        return sortDirection === 'desc' ? b.marketCap - a.marketCap : a.marketCap - b.marketCap;
    });

    const table = document.getElementById('crypto-data-table');
    table.innerHTML = '';

    const head = document.getElementById('head');

    const headerRow = `
        <div class="col-1">
            #
        </div>
        <div class="col-2">
            Coin
        </div>
        <div class="col-3">
            Price
        </div>
        <div class="col-3">
            ${sortByVolume ? 'Volume' : '24HR'}
        </div>
        <div class="col-3">
            Market
        </div>
    `;
    head.innerHtml += headerRow;

    // Add ranking and display data
    sortedData.forEach(data => {
        const {
            symbol,
            price,
            priceChangePercent,
            marketCap,
            volume
        } = data;

        const row = `
            <div class="row border-bottom">
                <div class="col-1 text-center">
                    ${rankingMap[symbol]}
                </div>
                <div class="col-1 text-center">
                    ${symbol}
                </div>
                <div class="col-3 text-center">
                    ${price.toFixed(2)}
                </div>
                <div class="col-4 text-center">
                    ${sortByVolume ? 
                        `<span id="${symbol}-arrow"></span>
                        <span id="${symbol}-percentage">${formatVolumePercentage(volume)}</span>` : // Show volume when sorting by volume
                        `<span id="${symbol}-arrow"></span>
                        <span id="${symbol}-percentage">${formatVolumePercentage(priceChangePercent)}</span>` // Show priceChangePercent otherwise
                    }
                </div>
                <div class="col-3 text-right">
                    ${formatMarketCap(marketCap)}
                </div>
        </div>
        `;
        table.innerHTML += row;

        // Update arrow and color based on priceChangePercent
        const arrowElement = document.getElementById(`${symbol}-arrow`);
        const volElement = document.getElementById(`${symbol}-percentage`);

        if (priceChangePercent > 0) {
            arrowElement.classList.add('up');
            arrowElement.classList.remove('down');
            volElement.classList.add('up');
            volElement.classList.remove('down');
            arrowElement.innerHTML = '<i class="fa-solid fa-caret-up"></i>'; // Up arrow
        } else if (priceChangePercent < 0) {
            arrowElement.classList.add('down');
            arrowElement.classList.remove('up');
            volElement.classList.add('down');
            volElement.classList.remove('up');
            arrowElement.innerHTML = '<i class="fa-solid fa-caret-down"></i>'; // Down arrow
        } else {
            arrowElement.classList.add('neutral');
            arrowElement.classList.remove('up');
            arrowElement.classList.remove('down');
            volElement.classList.add('neutral');
            volElement.classList.remove('up');
            volElement.classList.remove('down');
            arrowElement.innerHTML = '<i class="fa-solid fa-caret-right"></i>'; // Neutral arrow
        }
    });
}

export function toggleSortDirection() {
    sortDirection = sortDirection === 'desc' ? 'asc' : 'desc';
}

export function toggleSortByVolume() {
    sortByVolume = !sortByVolume; // Toggle the sort by volume
    displayData(cryptoData);
}