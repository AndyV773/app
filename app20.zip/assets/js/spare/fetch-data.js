async function fetchData(ticker, name) {
    try {
        const API_URL_GECKO = `https://api.coingecko.com/api/v3/coins/${name}`;
        const responseGecko = await fetch(API_URL_GECKO);
        if (!responseGecko.ok) {
            throw new Error(`HTTP error! status G: ${responseGecko.status}`);
        }
        const API_URL_BINANCE = `https://api.binance.com/api/v3/ticker/24hr?symbol=${ticker}USDT`;
        const responseBinance = await fetch(API_URL_BINANCE);
        if (!responseBinance.ok) {
            throw new Error(`HTTP error! status B: ${responseBinance.status}`);
        }

        const dataGecko = await responseGecko.json();
        const dataBinance = await responseBinance.json();

        const usdtData = data.find(coin => coin.symbol === 'USDTUSDT');

        Get data coingecko
        const price = dataGecko.market_data.current_price.usd; // Current price in USD
        const marketCap = dataGecko.market_data.market_cap.usd; // Market cap in USD
        const rank = dataGecko.market_cap_rank;
        Get the volume data coingecko
        const volumeChange = dataGecko.market_data.price_change_percentage_24h; // Percentage change


        Get data binance
        const price = dataBinance.lastPrice; // Current price in USD
        const newPrice = parseFloat(price).toString();
        const marketCap = price * circulatingSupplie; // Market cap in USD
        const marketCap = parseFloat(oldMarketCap).toString();
        Get the volume data binance
        const volumeChange = dataBinance.volume; // Percentage change  .toFixed(2)
        const volumeChange = dataBinance.priceChangePercent;


    } catch (error) {
        console.error('Error fetching data:', error);
    }

    return {ticker, name, price, volumeChange};

};

export {
    fetchData
};

// Set an interval to fetch prices every 30 seconds
// setInterval(fetchPriceBtc, 100000); // 30000 milliseconds = 30 seconds

