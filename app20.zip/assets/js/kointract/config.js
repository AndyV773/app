export const privateKey = "5KivaDN63VTNjbFjcNAspsRWeq6xoMnWU9XY6ruq22QGaNueEC2"
export const mainUrl = "https://api.koinos.io";
export const koinId = "15DJN4a8SgrbGhhGksSBASiSYjGnMU8dGL";

const test1 = '1QA8YRYtg4rZZmFHs1jMfDWSzaXsrj4jcv'; // test1
const test2 = '1L2BqGYybxZHMmRJBJqA4Ztyfzv3TbPMw'; // test2